<?php
require_once 'koneksi.php';
if (isset($_POST['submit'])) {
  $id_distributor = $_POST['id_distributor'];
  $nama_distributor = $_POST['nama_distributor'];
  $alamat_distributor = $_POST['alamat_distributor'];
  

  // update data berdasarkan id_produk yg dikirimkan
  
	$query = "UPDATE  data_distributor  SET NAMA_DISTRIBUTOR ='".$nama_distributor."', ALAMAT_DISTRIBUTOR = '".$alamat_distributor."' WHERE ID_DISTRIBUTOR = '".$id_distributor."' ";
	$statement = oci_parse($koneksi,$query);
	$r = oci_execute($statement,OCI_DEFAULT);
	 $res = oci_commit($koneksi);
  if ($res) {
    // pesan jika data berubah
    echo "<script>alert('Data Distributor berhasil diubah'); window.location.href='data_distributor1.php'</script>";
  } else {
    // pesan jika data gagal diubah
    echo "<script>alert('Data Distributor gagal diubah'); window.location.href='data_distributor1.php'</script>";
  }
} else {
  // jika coba akses langsung halaman ini akan diredirect ke halaman index
  header('Location: data_distributor1.php'); 
}