<?php
require_once 'koneksi.php';
if (isset($_POST['submit'])) {
  if (isset($_POST['submit'])) {
  $id = $_POST['id'];
  $judul_buku = $_POST['judul'];
  $pengarang = $_POST['pengarang'];
  $kategori = $_POST['kategori'];
  $stok = $_POST['stok'];
  $harga_buku = $_POST['harga_buku'];
  
  
	$query = "INSERT INTO data_buku (id_buku, judul_buku, pengarang_buku, kategori_buku, stok_buku, harga_buku) VALUES ('".$id."','".$judul_buku."','".$pengarang."', '".$kategori."', '".$stok."', '".$harga_buku."')";
	$statement = oci_parse($koneksi,$query);
	$r = oci_execute($statement,OCI_DEFAULT);
	 $res = oci_commit($koneksi);
  if ($res) {
    // pesan jika data tersimpan
    echo "<script>alert('Data Buku berhasil ditambahkan'); 
	window.location.href='data_buku1.php'</script>";
  } else {
    // pesan jika data gagal disimpan
    echo "<script>alert('Data Buku gagal ditambahkan');
	window.location.href='data_buku1.php'</script>";
  }
} else {
  //jika coba akses langsung halaman ini akan diredirect ke halaman index
  header('Location: data_buku1.php'); 
}
}