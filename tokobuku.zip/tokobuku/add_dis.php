<?php
require_once 'koneksi.php';
if (isset($_POST['submit'])) {
  if (isset($_POST['submit'])) {
  $id_distributor = $_POST['id_distributor'];
  $nama_distributor = $_POST['nama_distributor'];
  $alamat_distributor = $_POST['alamat_distributor'];
  
  
	$query = "INSERT INTO data_distributor (id_distributor, nama_distributor, alamat_distributor) VALUES ('".$id_distributor."','".$nama_distributor."', '".$alamat_distributor."' )";
	$statement = oci_parse($koneksi,$query);
	$r = oci_execute($statement,OCI_DEFAULT);
	 $res = oci_commit($koneksi);
  if ($res) {
    // pesan jika data tersimpan
    echo "<script>alert('Data Distributor berhasil ditambahkan'); 
	window.location.href='data_distributor1.php'</script>";
  } else {
    // pesan jika data gagal disimpan
    echo "<script>alert('Data Distributor gagal ditambahkan');
	window.location.href='data_distributor1.php'</script>";
  }
} else {
  //jika coba akses langsung halaman ini akan diredirect ke halaman index
  header('Location: data_distributor1.php'); 
}
}