<?php
$koneksi = oci_connect("pputrii_10038","pputrii_10038","LOCALHOST/XE");
/*
 di tulis oleh : PUTRI
 */
$kursor = ocicommit($koneksi);
?>