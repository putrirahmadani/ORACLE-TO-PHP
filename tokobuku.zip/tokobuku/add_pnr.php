<?php
require_once 'koneksi.php';
if (isset($_POST['submit'])) {
  if (isset($_POST['submit'])) {
  $id = $_POST['id'];
  $nama_penerbit = $_POST['nama'];
  
  
	$query = "INSERT INTO data_penerbit (id_penerbit, nama_penerbit) VALUES ('".$id."','".$nama_penerbit."')";
	$statement = oci_parse($koneksi,$query);
	$r = oci_execute($statement,OCI_DEFAULT);
	 $res = oci_commit($koneksi);
  if ($res) {
    // pesan jika data tersimpan
    echo "<script>alert('Data Penerbit berhasil ditambahkan'); 
	window.location.href='data_penerbit1.php'</script>";
  } else {
    // pesan jika data gagal disimpan
    echo "<script>alert('Data Penerbit gagal ditambahkan');
	window.location.href='data_penerbit1.php'</script>";
  }
} else {
  //jika coba akses langsung halaman ini akan diredirect ke halaman index
  header('Location: data_penerbit1.php'); 
}
}