<?php
require_once 'koneksi.php';
// cek id
if (isset($_GET['id_penerbit'])) {
  $ID = $_GET['id_penerbit'];
  $sql = "delete from data_penerbit where id_penerbit='$ID' ";
  $parsesql = oci_parse($koneksi, $sql);
  $q = oci_execute($parsesql) or die(oci_error());
  
  // cek perintah
  if ($q) {
    // pesan apabila hapus berhasil
    echo "<script>alert('Data berhasil dihapus'); window.location.href='data_penerbit1.php'</script>";
  } else {
    // pesan apabila hapus gagal
    echo "<script>alert('Data gagal dihapus'); window.location.href='data_penerbit1.php'</script>";
  }
} else {
  // jika mencoba akses langsung ke file ini akan diredirect ke halaman index
  header('Location:data_penerbit1.php');
}