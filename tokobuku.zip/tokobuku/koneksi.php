<?php
//membangun koneksi
$username ="pputrii_10038";
$password ="pputrii_10038";
$database ="LOCALHOST/XE";

$koneksi=oci_connect ($username,$password,$database);

if(!$koneksi) {
$err=oci_error();
echo "Gagal tersambung ke ORACLE", $err['text'];
} else {
	echo "Koneksi Berhasil";
}
?>