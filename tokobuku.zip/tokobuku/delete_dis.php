<?php
require_once 'koneksi.php';
// cek id
if (isset($_GET['id_distributor'])) {
  $ID = $_GET['id_distributor'];
  $sql = "delete from data_distributor where id_distributor='$ID' ";
  $parsesql = oci_parse($koneksi, $sql);
  $q = oci_execute($parsesql) or die(oci_error());
  
  // cek perintah
  if ($q) {
    // pesan apabila hapus berhasil
    echo "<script>alert('Data berhasil dihapus'); window.location.href='data_distributor1.php'</script>";
  } else {
    // pesan apabila hapus gagal
    echo "<script>alert('Data gagal dihapus'); window.location.href='data_distributor1.php'</script>";
  }
} else {
  // jika mencoba akses langsung ke file ini akan diredirect ke halaman index
  header('Location:data_distributor1.php');
}