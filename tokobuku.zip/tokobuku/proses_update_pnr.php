<?php
require_once 'koneksi.php';
if (isset($_POST['submit'])) {
  $id = $_POST['id'];
  $nama_penerbit = $_POST['nama'];
  
 
  
  // update data berdasarkan id_produk yg dikirimkan
  
	$query = "UPDATE  data_penerbit  SET NAMA_PENERBIT ='".$nama_penerbit."' WHERE ID_PENERBIT = '".$id."' ";
	$statement = oci_parse($koneksi,$query);
	$r = oci_execute($statement,OCI_DEFAULT);
	 $res = oci_commit($koneksi);
  if ($res) {
    // pesan jika data berubah
    echo "<script>alert('Data Penerbit berhasil diubah'); window.location.href='data_penerbit1.php'</script>";
  } else {
    // pesan jika data gagal diubah
    echo "<script>alert('Data Penerbit gagal diubah'); window.location.href='data_penerbit1.php'</script>";
  }
} else {
  // jika coba akses langsung halaman ini akan diredirect ke halaman index
  header('Location: data_penerbit1.php'); 
}