<?php
require_once 'koneksi.php';
if (isset($_POST['submit'])) {
  $id = $_POST['id'];
  $judul_buku = $_POST['judul_buku'];
  $pengarang = $_POST['pengarang'];
  $kategori = $_POST['kategori'];
  $stok = $_POST['stok'];
  $harga_buku = $_POST['harga_buku'];
  
  // update data berdasarkan id_produk yg dikirimkan
  
	$query = "UPDATE  data_buku SET JUDUL_BUKU ='".$judul_buku."', PENGARANG_BUKU ='".$pengarang."', KATEGORI_BUKU='".$kategori."' , STOK_BUKU ='".$stok."', HARGA_BUKU ='".$harga_buku."'WHERE ID_BUKU= '".$id."' ";
	$statement = oci_parse($koneksi,$query);
	$r = oci_execute($statement, OCI_DEFAULT);
	 $res = oci_commit($koneksi);
  if ($res) {
    // pesan jika data berubah
    echo "<script>alert('Data buku berhasil diubah'); window.location.href='data_buku1.php'</script>";
  } else {
    // pesan jika data gagal diubah
    echo "<script>alert('Data Buku gagal diubah'); window.location.href='data_buku1.php'</script>";
  }
} else {
  // jika coba akses langsung halaman ini akan diredirect ke halaman index
  header('Location: data_buku1.php'); 
}
